import java.util.Scanner;

class CircularQueue {
    private int front, rear, size, maxSize;
    private int[] queue;

    // Constructor to initialize Circular Queue with initial values
    public CircularQueue(int initSize, int[] initValues) {
        maxSize = 10;
        size = initSize;
        queue = new int[maxSize];
        front = 0;
        rear = size - 1;

        // Initialize the queue with given values
        for (int i = 0; i < size; i++) {
            queue[i] = initValues[i];
        }
    }

    // Check if queue is empty
    public boolean isEmpty() {
        return size == 0;
    }

    // Check if queue is full (maxSize is fixed at 10)
    public boolean isFull() {
        return size == maxSize;
    }

    // Insert an element into the queue (Push)
    public void enqueue(int value) {
        if (isFull()) {
            System.out.println("Queue is Full!");
            return;
        }
        rear = (rear + 1) % maxSize;
        queue[rear] = value;
        size++;
        System.out.println(value + " inserted.");
    }

    // Delete an element from the queue (Pop)
    public void dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is Empty!");
            return;
        }
        System.out.println("Deleted: " + queue[front]);
        front = (front + 1) % maxSize;
        size--;
    }

    // Display the queue elements
    public void display() {
        if (isEmpty()) {
            System.out.println("Queue is Empty!");
            return;
        }
        System.out.print("Queue: ");
        int i = front, count = 0;
        while (count < size) {
            System.out.print(queue[i] + " ");
            i = (i + 1) % maxSize;
            count++;
        }
        System.out.println();
    }
}

public class CircularQueueMenu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int initSize;

        // Take input for initial size (max 10)
        while (true) {
            System.out.print("Enter the initial queue size (max 10): ");
            initSize = scanner.nextInt();
            if (initSize > 0 && initSize <= 10) break;
            System.out.println("Error: Size must be between 1 and 10.");
        }

        int[] initValues = new int[initSize];
        System.out.println("Enter " + initSize + " initial values:");
        for (int i = 0; i < initSize; i++) {
            initValues[i] = scanner.nextInt();
        }

        CircularQueue queue = new CircularQueue(initSize, initValues);

        // Queue Menu
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Push (Enqueue)");
            System.out.println("2. Pop (Dequeue)");
            System.out.println("3. Display");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1: // Push (Enqueue)
                    while (true) {
                        if (queue.isFull()) {
                            System.out.println("Queue is Full!");
                            break;
                        }
                        System.out.print("Enter element to push: ");
                        int value = scanner.nextInt();
                        queue.enqueue(value);
                        if (queue.isFull()) {
                            System.out.println("Queue reached max size (10).");
                            break;
                        }
                        System.out.print("Do you want to push another? (yes/no): ");
                        if (!scanner.next().equalsIgnoreCase("yes")) break;
                    }
                    break;
                    
                case 2: // Pop (Dequeue)
                    while (true) {
                        queue.dequeue();
                        if (queue.isEmpty()) break;
                        System.out.print("Do you want to delete more? (yes/no): ");
                        if (!scanner.next().equalsIgnoreCase("yes")) break;
                    }
                    break;
                    
                case 3: // Display
                    queue.display();
                    break;
                    
                case 4: // Exit
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                    
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
    }
}
