//program 6
import java.util.Scanner;

public class ArrayOperations {
    private int[] arr;
    private int size;
    private int fixsize;
    private int sizetocheck;
    private boolean created=true;

    // Constructor to initialize the array
    public ArrayOperations() {
        arr = new int[10];  // Maximum size of the array is 10
        size = 0; 
                   // Initialize size to 0
    }

    // Method to create an array and input elements
    public void create() {
      if(created){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        size = sc.nextInt();
        if(size<1 || size >10)
        {System.out.println("Enter a number between 1 and 10");
        return;
        }
      
        System.out.println("Enter the elements:");
        for (int i = 0; i < size; i++) {
            arr[i] = sc.nextInt();
        }
        System.out.println("Array created successfully.");
        created=false;
    }
    else{ System.out.println("Array is already created");
    }
}
    // Method to insert an element at a specified position
// Method to insert an element at a specified position
public void insert() {
    Scanner sc = new Scanner(System.in);
    boolean insertMore = true;

    if (size == 0) {
        System.out.println("Insertion operation. Create the array first.");
        return;
    }
    
    // Check if the array is full
  

    while (insertMore) {
        // Ensure the array isn't full
        if (size >= 10) {
            System.out.println("Array is full, cannot insert more elements.");
            break; // Exit loop if the array is full
        }

        // Get position to insert (1-based index)
        System.out.print("Enter the position to insert (1-based index): ");
        int pos = sc.nextInt();

        // Validate position
        if (pos < 1 || pos > size + 1) {
            System.out.println("Invalid position. Please enter a valid position.");
            continue;
        }

        // Get element to insert
        System.out.print("Enter the element to insert: ");
        int element = sc.nextInt();

        // Shift elements to the right to make space
        for (int j = size; j >= pos; j--) {
            arr[j] = arr[j - 1];
        }

        arr[pos - 1] = element; // Insert the new element at the position
        size++;

        // Ask the user if they want to insert another element
        System.out.print("Do you want to insert another element? (yes/no): ");
        String response = sc.next();
        insertMore = response.equalsIgnoreCase("yes");
    }

    System.out.println("Elements inserted successfully.");
}


    // Method to delete an element from a specified position
    public void delete() {
        Scanner sc = new Scanner(System.in);
        boolean deleteMore = true;
        if (size == 0) {
        System.out.println("The array is empty.");
        return;  // Exit the method if the array is empty
    }

        while (deleteMore) {
            System.out.print("Enter the position to delete from (1-based index): ");
            int pos = sc.nextInt();
            if (pos < 1 || pos > size) {
                System.out.println("Invalid position.");
                continue;
            }
             
            // Shift elements to the left
            for (int j = pos - 1; j < size - 1; j++) {
                arr[j] = arr[j + 1];
            }
            size--;
            
            if(size==0){
            sizetocheck=-1;}

            System.out.print("Do you want to delete another element? (yes/no): ");
            String response = sc.next();
            deleteMore = response.equalsIgnoreCase("yes");
            if (size == 0) {
        System.out.println("The array is empty.");
        return;  // Exit the method if the array is empty
    }

        }
        System.out.println("Elements deleted successfully.");
    }

    // Method to traverse and display the array
    public void traverse() {
        if (size == 0) {
            System.out.println("The array is empty.");
            return;
        }
        System.out.println("Array elements are:");
        for (int i = 0; i < size; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    // Method to search for an element
    public void search() {
        Scanner sc = new Scanner(System.in);
        if (size == 0) {
            System.out.println("The array is empty.");
            return;
        }
        System.out.print("Enter the element to search for: ");
        int element = sc.nextInt();
        for (int i = 0; i < size; i++) {
            if (arr[i] == element) {
                System.out.println("Element found at position " + (i + 1));
                return;
            }
        }
        System.out.println("Element not found.");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayOperations ao = new ArrayOperations();
        int choice;

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Create Array");
            System.out.println("2. Insert Elements");
            System.out.println("3. Delete Elements");
            System.out.println("4. Traverse Array");
            System.out.println("5. Search Element");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    ao.create();
                    break;
                case 2:
                    ao.insert();
                    break;
                case 3:
                    ao.delete();
                    break;
                case 4:
                    ao.traverse();
                    break;
                case 5:
                    ao.search();
                    break;
                case 6:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        } while (choice != 6);}}
    


