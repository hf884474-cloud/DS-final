import java.util.Scanner;

public class ArrayStackPushMore {
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        final int maxsize = 10;
        int[] stack = new int[maxsize];
        int top = -1, n;

        // Initial elements input
        while (true) {
            System.out.println("Enter the number of elements to push(1-10):");
            n = scanner.nextInt();
            if (n >= 1 && n <= maxsize) break;
            System.out.println("Error: Enter a number between 1 and 10.");
        }

        // Push initial elements into the stack
        for (int i = 0; i < n; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            stack[++top] = scanner.nextInt();
        }

        // Ask if the user wants to push more elements
        while (top < maxsize - 1) {
            System.out.print("Do you want to push an element to the stack? (yes/no): ");
            String choice = scanner.next().trim().toLowerCase();
            if (choice.equals("yes")) {
                System.out.print("Enter element to push: ");
                stack[++top] = scanner.nextInt();
            } else if (choice.equals("no")) break;
            else System.out.println("Error: Enter 'yes' or 'no'.");
        }
if(top>=maxsize-1)
{
System.out.println("The stack is full");
}

        // Display final stack
        System.out.println("Final stack:");
        if (top == -1) System.out.println("Empty");
        else for (int i = 0; i <= top; i++) System.out.println(stack[i]);

        scanner.close();
    }
}

