import java.util.Scanner;

public class ArrayDeletionFromEnd {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Initialize array and variables
        int maxSize = 10; // Maximum size of the array
        int[] array = new int[maxSize];
        int currentSize = 0; // Tracks the current number of elements in the array

        // Ask user to enter the initial size of the array
        System.out.print("Enter the number of elements (0 - " + maxSize + "): ");
        int n = scanner.nextInt();

        // Validate the initial size
        if (n < 1 || n > maxSize) {
            System.out.println("Error: Invalid size. Exiting program...");
            scanner.close();
            return;
        }

        // Read 'n' elements into the array
        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            array[i] = scanner.nextInt();
            currentSize++;
        }

        // Display the initial array
        System.out.print("Initial array: ");
        for (int i = 0; i < currentSize; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();

        // Loop to delete elements from the end as per user input
        String choice;
        while (currentSize > 0) {
            System.out.print("Do you want to delete an element from the end? (yes/no): ");
            choice = scanner.next();

            if (choice.equalsIgnoreCase("yes")) {
                // Reduce the size of the array by one (deleting from the end)
                currentSize--;

                // Display the updated array
                if(currentSize>0)
                {
                System.out.print("Updated array: ");
                for (int i = 0; i < currentSize; i++) {
                    System.out.print(array[i] + " ");
                }
                System.out.println();
              }  else
              {
              System.out.println("Array is empty");
              }
            } else if (choice.equalsIgnoreCase("no")) {
                break;
            } else {
                System.out.println("Invalid input, please enter 'yes' or 'no'.");
            }
            
        }
if(currentSize>0)
{
        System.out.println("Final array: ");
        for (int i = 0; i < currentSize; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
        }

        scanner.close();
    }
}


