import java.util.Scanner;

public class ArrayStackPush {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Initialize stack variables
        int maxSize = 10; // Maximum size of the stack
        int[] stack = new int[maxSize];
        int top = -1; // Top pointer of the stack

        System.out.println("Stack initialized with a maximum size of " + maxSize + ".");

        // Initial number of elements to push
        System.out.print("Enter the number of elements to push: ");
        int n = scanner.nextInt();

        // Validate the initial number of elements
        if (n <= 0) {
            System.out.println("Error: Number of elements must be greater than 0.");
            scanner.close();
            return;
        } else if (n > maxSize) {
            System.out.println("Error: You can only push up to " + maxSize + " elements.");
            scanner.close();
            return;
        }

        // Push the initial elements
        System.out.println("Enter " + n + " elements to push into the stack:");
        for (int i = 0; i < n; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            int element = scanner.nextInt();
            stack[++top] = element; // Increment top and push element
        }

        // Display the stack after pushing the initial elements
        System.out.print("Stack after pushing initial elements: ");
        for (int i = 0; i <= top; i++) {
            System.out.print(stack[i] + " ");
        }
        System.out.println();

        // Main loop to ask if the user wants to push more elements
        while (true) {
            System.out.print("Do you want to push an element into the stack? (yes/no): ");
            String response = scanner.next();

            if (response.equalsIgnoreCase("yes")) {
                if (top >= maxSize - 1) {
                    System.out.println("Error: Stack is full. Cannot push more elements.");
                    break;
                }

                // Prompt for the element to push
                System.out.print("Enter the element to push: ");
                int element = scanner.nextInt();
                stack[++top] = element; // Increment top and push element

                // Display the stack after pushing the element
                System.out.print("Stack after pushing the element: ");
                for (int i = 0; i <= top; i++) {
                    System.out.print(stack[i] + " ");
                }
                System.out.println();

            } else if (response.equalsIgnoreCase("no")) {
                System.out.println("Exiting program.");
                break;
            } else {
                System.out.println("Invalid response. Please enter 'yes' or 'no'.");
            }
        }

        scanner.close();
    }
}

