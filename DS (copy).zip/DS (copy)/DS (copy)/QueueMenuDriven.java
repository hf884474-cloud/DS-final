import java.util.Scanner;

public class QueueMenuDriven {
    static final int DEFAULT_MAX_SIZE = 10; // Max size limit
    static int MAX_SIZE; 
    static int queue[];
    static int front = -1, rear = -1; // Pointers

    // Initialize the queue with initial elements
    static void createQueue(Scanner scanner) {
        System.out.println("Maximum allowed queue size is " + DEFAULT_MAX_SIZE);
        
        while (true) {
            System.out.print("Enter the initial size of the queue (1-10): ");
            if (scanner.hasNextInt()) {
                MAX_SIZE = scanner.nextInt();
                if (MAX_SIZE > 0 && MAX_SIZE <= DEFAULT_MAX_SIZE) {
                    queue = new int[DEFAULT_MAX_SIZE]; // Max array size fixed
                    front = 0;
                    rear = MAX_SIZE - 1; 

                    System.out.println("Enter " + MAX_SIZE + " initial elements:");
                    for (int i = 0; i < MAX_SIZE; i++) {
                        while (!scanner.hasNextInt()) {
                            System.out.println("Error: Enter a valid integer.");
                            scanner.next();
                        }
                        queue[i] = scanner.nextInt();
                    }
                    System.out.println("Queue initialized with " + MAX_SIZE + " elements.");
                    return;
                } else {
                    System.out.println("Error: Size must be between 1 and " + DEFAULT_MAX_SIZE + ".");
                }
            } else {
                System.out.println("Error: Enter a valid number.");
                scanner.next(); // Consume invalid input
            }
        }
    }

    // Insert element into queue
    static void enqueue(Scanner scanner) {
        while (true) {
            if (rear == DEFAULT_MAX_SIZE - 1) { // Limit to DEFAULT_MAX_SIZE
                System.out.println("Queue is full! Cannot insert more elements.");
                return;
            }
            System.out.print("Enter element to insert: ");
            while (!scanner.hasNextInt()) {
                System.out.println("Error: Enter a valid integer.");
                scanner.next();
            }
            int element = scanner.nextInt();
            queue[++rear] = element;
            System.out.println("Inserted: " + element);

            if (rear == DEFAULT_MAX_SIZE - 1) {
                System.out.println("Queue has reached the max size of " + DEFAULT_MAX_SIZE);
                break;
            }

            System.out.print("Do you want to insert another element? (yes/no): ");
            String choice = scanner.next().trim().toLowerCase();
            if (choice.equals("no")) break;
            else if (!choice.equals("yes")) {
                System.out.println("Invalid input! Returning to menu.");
                break;
            }
        }
    }

    // Remove element from queue
    static void dequeue(Scanner scanner) {
        while (true) {
            if (front > rear) {
                System.out.println("Queue is empty! Nothing to delete.");
                return;
            }
            System.out.println("Deleted: " + queue[front++]);

            if (front > rear) { // Reset when queue becomes empty
                front = 0;
                rear = MAX_SIZE - 1;
                System.out.println("Queue is now empty.");
                break;
            }

            System.out.print("Do you want to delete another element? (yes/no): ");
            String choice = scanner.next().trim().toLowerCase();
            if (choice.equals("no")) break;
            else if (!choice.equals("yes")) {
                System.out.println("Invalid input! Returning to menu.");
                break;
            }
        }
    }

    // Display queue elements
    static void display() {
        if (front > rear) {
            System.out.println("Queue is empty!");
            return;
        }
        System.out.print("Queue elements: ");
        for (int i = front; i <= rear; i++) {
            System.out.print(queue[i] + " ");
        }
        System.out.println();
    }

    // Main menu-driven function
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        createQueue(scanner); // Initialize queue first

        do {
            System.out.println("\nQueue Operations:");
            System.out.println("1. Insert (Enqueue)");
            System.out.println("2. Delete (Dequeue)");
            System.out.println("3. Display Queue");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            while (!scanner.hasNextInt()) {
                System.out.println("Error: Enter a valid option (1-4).");
                scanner.next();
            }
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    enqueue(scanner);
                    break;
                case 2:
                    dequeue(scanner);
                    break;
                case 3:
                    display();
                    break;
                case 4:
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid choice! Enter a number between 1-4.");
            }
        } while (choice != 4);

        scanner.close();
    }
}
