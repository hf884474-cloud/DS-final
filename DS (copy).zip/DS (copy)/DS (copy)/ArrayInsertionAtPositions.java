import java.util.Scanner;

public class ArrayInsertionAtPositions {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Initialize array and variables
        int maxSize = 10; // Maximum size of the array
        int[] array = new int[maxSize];
        int currentSize = 0; // Tracks the current number of elements in the array

        // Ask user to enter the initial size of the array
        System.out.print("Enter the number of elements (limit) you want to insert initially (0 - " + maxSize + "): ");
        int n = scanner.nextInt();

        // Validate the initial size
        if (n < 0 || n > maxSize) {
            System.out.println("Error: Invalid limit. The limit must be between 0 and " + maxSize + ".");
            System.out.println("Exiting program...");
            scanner.close();
            return;
        }

        // Read 'n' elements from the user
        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            array[i] = scanner.nextInt();
            currentSize++;
        }

        // Display the initial array
        System.out.print("Initial array: ");
        for (int i = 0; i < currentSize; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();

        // Loop to insert elements at specified positions
        while (true) {
            System.out.print("Do you want to insert an element at a specified position? (yes/no): ");
            String userResponse = scanner.next();

            if (userResponse.equalsIgnoreCase("yes")) {
                // Check if there is space in the array
                if (currentSize >= maxSize) {
                    System.out.println("Error: Array is full. Cannot insert more elements.");
                    break;
                }

                // Read the new element and its position
                System.out.print("Enter the element to insert: ");
                int newElement = scanner.nextInt();

                System.out.print("Enter the position (0-based index) to insert element " + newElement + ": ");
                int position = scanner.nextInt();

                // Validate the position
                if (position < 0 || position > currentSize) {
                    System.out.println("Error: Invalid position. Position must be between 0 and " + currentSize + ".");
                } else {
                    // Shift elements to the right to make space
                    for (int j = currentSize; j > position; j--) {
                        array[j] = array[j - 1];
                    }
                    // Insert the new element
                    array[position] = newElement;
                    currentSize++;

                    // Display the updated array
                    System.out.print("Updated array: ");
                    for (int i = 0; i < currentSize; i++) {
                        System.out.print(array[i] + " ");
                    }
                    System.out.println();
                }

            } else if (userResponse.equalsIgnoreCase("no")) {
                System.out.println("No more elements to insert. Exiting program.");
                break;
            } else {
                System.out.println("Invalid response. Please enter 'yes' or 'no'.");
            }
        }

        // Close the scanner
        scanner.close();
    }
}

