import java.util.Scanner;

public class ArrayStackPushMore {
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        final int maxsize = 10;
        int[] stack = new int[maxsize];
        int top = -1;
        int n;

        while (true) {
            System.out.println("Enter the number of elements to push (1-10):");
            if (scanner.hasNextInt()) {
                n = scanner.nextInt();
                scanner.nextLine(); // Consume newline left by nextInt()
                if (n >= 1 && n <= maxsize) {
                    break;
                } else {
                    System.out.println("Error: Enter a number between 1 and 10.");
                }
            } else {
                System.out.println("Error: Invalid input. Please enter a valid number.");
                scanner.next(); // Consume invalid input
            }
        }

        // Input the elements to push into the stack
        for (int i = 0; i < n; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            while (!scanner.hasNextInt()) {
                System.out.println("Error: Enter a valid integer.");
                scanner.next(); // Consume invalid input
                System.out.print("Enter element " + (i + 1) + ": ");
            }
            stack[++top] = scanner.nextInt();
            scanner.nextLine(); // Consume newline left by nextInt()
        }

        // New functionality: Push more than one element into the stack
        while (true) { // Allow pushing more elements
            System.out.print("Do you want to push more elements? (yes/no): ");
            String choice = scanner.nextLine().trim().toLowerCase();
            
            if (choice.equals("yes")) {
                // Get the number of elements to push
                System.out.println("Enter the number of elements to push (1-10):");
                int moreElements;
                while (true) {
                    if (scanner.hasNextInt()) {
                        moreElements = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        if (moreElements >= 1 && moreElements <= (maxsize - top - 1)) { // Ensure space is available
                            break;
                        } else {
                            System.out.println("Error: Enter a valid number of elements (up to " + (maxsize - top - 1) + " more elements).");
                        }
                    } else {
                        System.out.println("Error: Invalid input. Please enter a valid number.");
                        scanner.next(); // Consume invalid input
                    }
                }

                // Input the additional elements to push into the stack
                for (int i = 0; i < moreElements; i++) {
                    System.out.print("Enter additional element " + (i + 1) + ": ");
                    while (!scanner.hasNextInt()) {
                        System.out.println("Error: Enter a valid integer.");
                        scanner.next(); // Consume invalid input
                        System.out.print("Enter additional element " + (i + 1) + ": ");
                    }
                    stack[++top] = scanner.nextInt();
                    scanner.nextLine(); // Consume newline left by nextInt()
                }

            } else if (choice.equals("no")) {
                break;
            } else {
                System.out.println("Error: Enter 'yes' or 'no'.");
            }
        }

        // Print the final stack
        System.out.println("Final stack:");
        if (top == -1) {
            System.out.println("Empty");
        } else {
            for (int i = 0; i <= top; i++) {
                System.out.println(stack[i]);
            }
        }

        scanner.close();
    }
}

