//program 10
import java.util.Scanner;

public class simpleQueue {
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        final int max_size = 10;
        int[] queue = new int[max_size];
        int front = -1, rear = -1;
        int n;

        while (true) {
            System.out.println("Enter number of elements to enqueue (1-10):");
            if (scanner.hasNextInt()) {
                n = scanner.nextInt();
                if (n >= 1 && n <= max_size) break;
                else System.out.println("Error: Enter a number between 1 and 10.");
            } else {
                System.out.println("Error: Invalid input. Enter a number.");
                scanner.next();
            }
        }

        for (int i = 0; i < n; i++) {
            if (rear == max_size - 1) {
                System.out.println("Queue is full");
                break;
            }
            System.out.println("Enter element " + (i + 1) + ":");
            while (!scanner.hasNextInt()) {
                System.out.println("Error: Enter a valid integer.");
                scanner.next();
                System.out.println("Enter element " + (i + 1) + ":");
            }
            if (front == -1) front = 0;
            queue[++rear] = scanner.nextInt();
        }

        while (front <= rear && front != -1) {
            System.out.print("Do you want to delete an element? (yes/no): ");
            String choice = scanner.next().trim().toLowerCase();
            if (choice.equals("yes")) {
                System.out.println("Deleted: " + queue[front++]);
                if (front > rear) {
                    front = rear = -1;
                    break;
                }
            } else if (choice.equals("no")) {
                break;
            } else {
                System.out.println("Error: Enter 'yes' or 'no'.");
            }
        }

        if (front == -1 || front > rear) {
            System.out.println("Queue is empty!");
        } else {
            System.out.print("Final queue: ");
            for (int i = front; i <= rear; i++) {
                System.out.print(queue[i] + " ");
            }
            System.out.println();
        }
        scanner.close();
    }
}

