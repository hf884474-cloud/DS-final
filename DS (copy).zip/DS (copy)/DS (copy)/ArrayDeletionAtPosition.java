import java.util.Scanner;

public class ArrayDeletionAtPosition {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Initialize array and variables
        int maxSize = 10; // Maximum size of the array
        int[] array = new int[maxSize];
        int currentSize = 0; // Tracks the current number of elements in the array

        // Ask user to enter the initial size of the array
        System.out.print("Enter the number of elements (0 - " + maxSize + "): ");
        int n = scanner.nextInt();

        // Validate the initial size
        if (n < 0 || n > maxSize) {
            System.out.println("Error: Invalid size. Exiting program...");
            scanner.close();
            return;
        }

        // Read 'n' elements into the array
        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            array[i] = scanner.nextInt();
            currentSize++;
        }

        // Display the initial array
        System.out.print("Initial array: ");
        for (int i = 0; i < currentSize; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();

        // Loop for deleting elements
        while (true) {
        
         // Ask if the user wants to delete another element
         System.out.print("Do you want to delete another element? (yes/no): ");
         if(currentSize==0){}
            String response = scanner.next();
            if (response.equalsIgnoreCase("no")) {
                System.out.println("Exiting program.");
                break;
            } else if (!response.equalsIgnoreCase("yes")) {
                System.out.println("Invalid response. Exiting program.");
                break;
            }
            
            System.out.print("Enter the position (0-based index) to delete an element: ");
            int position = scanner.nextInt();
             if(currentSize==0){break;}
            // Validate the position
            if (position < 0 || position >= currentSize) {
                System.out.println("Error: Invalid position. Position must be between 0 and " + (currentSize - 1) + ".");
                if(currentSize<0){break;}
            } else {
                // Shift elements to the left to delete the element
                for (int i = position; i < currentSize - 1; i++) {
                    array[i] = array[i + 1];
                }
                currentSize--; 
                System.out.println("current size:"+currentSize);
                // Decrease the current size
                if(currentSize==0){break;}
                // Display the updated array
                if(currentSize>=0)
                {
                System.out.print("Updated array: ");
                for (int i = 0; i < currentSize; i++) {
                    System.out.print(array[i] + " ");
                }
                }else{ 
System.out.println("Array is empty");
}
                System.out.println();
            }

         
        }

        scanner.close();
    }
}

