import java.util.Scanner;

public class ArrayStackPop {
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        int maxsize = 10;
        int[] stack = new int[maxsize];
        int top = -1;

        System.out.println("Enter the number of elements to push (1-10):");

        int n = 0;
        if (scanner.hasNextInt()) {
            n = scanner.nextInt();
            if (n < 1 || n > maxsize) {
                System.out.println("Error: Enter a number between 1 and 10.");
                return;
            }
        } else {
            System.out.println("Error: Invalid input. Please enter a number.");
            scanner.next();
            return;
        }

        for (int i = 0; i < n; i++) {
            System.out.println("Enter element " + (i + 1) + ":");
            while (!scanner.hasNextInt()) {
                System.out.println("Error: Enter a valid integer.");
                scanner.next();
                System.out.print("Enter element " + (i + 1) + ":");
            }
            stack[++top] = scanner.nextInt();
        }

        while (top >= 0) {
            System.out.println("Do you want to delete an element? (yes/no):");
            String choice = scanner.next().trim().toLowerCase();
            if (choice.equals("yes")) {
                System.out.println("Deleted: " + stack[top--]);
            } else if (choice.equals("no")) {
                break;
            } else {
                System.out.println("Error: Enter 'yes' or 'no'.");
            }
        }

        System.out.println("Final stack:");
        if (top == -1) {
            System.out.println("Empty");
        } else {
            for (int i = 0; i <= top; i++) {
                System.out.print(stack[i] + " ");
            }
            System.out.println();
        }

        scanner.close();
    }
}

