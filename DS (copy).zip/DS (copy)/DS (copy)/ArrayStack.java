//infix to postfix
import java.util.Scanner;

class ArrayStack {
    private int top;
    private char[] stack;
    private int maxSize;

    // Constructor to initialize stack
    public ArrayStack(int size) {
        maxSize = size;
        stack = new char[maxSize];
        top = -1;
    }

    // Push an element onto the stack
    public void push(char ch) {
        if (top == maxSize - 1) {
            System.out.println("Stack Overflow");
        } else {
            stack[++top] = ch;
        }
    }

    // Pop an element from the stack
    public char pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            return '\0'; // Return null character if stack is empty
        } else {
            return stack[top--];
        }
    }

    // Peek at the top element of the stack
    public char peek() {
        if (isEmpty()) {
            return '\0';
        }
        return stack[top];
    }

    // Check if the stack is empty
    public boolean isEmpty() {
        return top == -1;
    }
}

public class InfixToPostfixArrayStack {

    // Function to get precedence of operators
    static int precedence(char ch) {
        switch (ch) {
            case '+': case '-': return 1;
            case '*': case '/': return 2;
            case '^': return 3;
            default: return -1; // Invalid operator
        }
    }

    // Function to convert infix to postfix using array stack
    static String infixToPostfix(String infix) {
        StringBuilder postfix = new StringBuilder();
        ArrayStack stack = new ArrayStack(infix.length());

        for (int i = 0; i < infix.length(); i++) {
            char ch = infix.charAt(i);

            // If operand, add to output
            if (Character.isLetterOrDigit(ch)) {
                postfix.append(ch);
            } 
            // If '(', push to stack
            else if (ch == '(') {
                stack.push(ch);
            } 
            // If ')', pop until '('
            else if (ch == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    postfix.append(stack.pop());
                }
                if (!stack.isEmpty() && stack.peek() == '(') {
                    stack.pop(); // Remove '('
                } else {
                    System.out.println("Error: Mismatched parentheses.");
                    return "";
                }
            } 
            // If operator, pop elements with higher precedence
            else {
                while (!stack.isEmpty() && precedence(stack.peek()) >= precedence(ch)) {
                    postfix.append(stack.pop());
                }
                stack.push(ch);
            }
        }

        // Pop remaining elements from stack
        while (!stack.isEmpty()) {
            if (stack.peek() == '(') {
                System.out.println("Error: Mismatched parentheses.");
                return "";
            }
            postfix.append(stack.pop());
        }

        return postfix.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter infix expression: ");
        String infix = scanner.nextLine();
        scanner.close();

        String postfix = infixToPostfix(infix);
        if (!postfix.isEmpty()) {
            System.out.println("Postfix Expression: " + postfix);
        }
    }
}