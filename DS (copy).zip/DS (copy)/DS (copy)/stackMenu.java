import java.util.Scanner;

public class stackMenu {
    private static final int MAX_SIZE = 10;  // Fixed maximum size of the stack
    private int[] stack;
    private int top;
    private Scanner scanner = new Scanner(System.in);

    // Constructor to create the stack and initialize values
    public stackMenu() {
        int initialSize;
        while (true) {
            System.out.print("Enter the initial stack size (≤ " + MAX_SIZE + "): ");
            if (scanner.hasNextInt()) {
                initialSize = scanner.nextInt();
                if (initialSize > 0 && initialSize <= MAX_SIZE) {
                    break;
                }
                System.out.println("Invalid size! Please enter a value between 1 and " + MAX_SIZE);
            } else {
                System.out.println("Invalid input! Please enter an integer.");
                scanner.next();  // Consume invalid input
            }
        }
        
        stack = new int[MAX_SIZE];  // Create a stack of max size
        top = initialSize - 1;  // Initialize `top` based on given size

        System.out.println("Enter " + initialSize + " elements to initialize the stack:");
        for (int i = 0; i < initialSize; i++) {
            while (true) {
                System.out.print("Enter element " + (i + 1) + ": ");
                if (scanner.hasNextInt()) {
                    stack[i] = scanner.nextInt();
                    break;
                } else {
                    System.out.println("Invalid input! Please enter an integer.");
                    scanner.next();
                }
            }
        }

        System.out.println("Stack initialized with " + initialSize + " elements.");
    }

    // Push operation
    public void push() {
        if (top == MAX_SIZE - 1) {
            System.out.println("Stack overflow! Cannot push more elements.");
            return;
        }

        while (top < MAX_SIZE - 1) {
            System.out.print("Enter the element to push: ");
            if (scanner.hasNextInt()) {
                stack[++top] = scanner.nextInt();
                System.out.println("Element pushed successfully.");
            } else {
                System.out.println("Invalid input! Please enter an integer.");
                scanner.next();  // Consume invalid input
                continue;
            }

            if (top == MAX_SIZE - 1) {
                System.out.println("Stack is full.");
                return;
            }

            System.out.print("Do you want to push another element? (yes/no): ");
            String choice = scanner.next().toLowerCase();
            if (!choice.equals("yes")) {
                return;
            }
        }
    }

    // Pop operation
    public void pop() {
        if (top == -1) {
            System.out.println("Stack underflow! No elements to pop.");
            return;
        }

        while (top >= 0) {
            System.out.println("Popped element: " + stack[top--]);

            if (top == -1) {
                System.out.println("Stack is now empty.");
                return;
            }

            System.out.print("Do you want to delete another element? (yes/no): ");
            String choice = scanner.next().toLowerCase();
            if (!choice.equals("yes")) {
                return;
            }
        }
    }

    // Peek operation
    public void peek() {
        if (top == -1) {
            System.out.println("Stack is empty!");
        } else {
            System.out.println("Top element: " + stack[top]);
        }
    }

    // Display the stack elements
    public void display() {
        if (top == -1) {
            System.out.println("Stack is empty.");
        } else {
            System.out.print("Stack elements: ");
            for (int i = 0; i <= top; i++) {
                System.out.print(stack[i] + " ");
            }
            System.out.println();
        }
    }

    // Display menu and handle user choices
    public void menu() {
        while (true) {
            System.out.println("\nStack Menu");
            System.out.println("1. Push");
            System.out.println("2. Pop");
            System.out.println("3. Peek");
            System.out.println("4. Display");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            
            if (scanner.hasNextInt()) {
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1 -> push();
                    case 2 -> pop();
                    case 3 -> peek();
                    case 4 -> display();
                    case 5 -> {
                        System.out.println("Exiting program.");
                        return;
                    }
                    default -> System.out.println("Invalid choice! Please enter a number between 1 and 5.");
                }
            } else {
                System.out.println("Invalid input! Please enter a number.");
                scanner.next();  // Consume invalid input
            }
        }
    }

    public static void main(String[] args) {
        stackMenu stackObj = new stackMenu();
        stackObj.menu();
    }
}
