import java.util.Scanner;

public class ArrayInsertion {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Initialize array and variables
        int maxSize = 10; // Maximum size of the array
        int[] array = new int[maxSize];
        int currentSize = 0; // Tracks the current number of elements in the array

        // Ask user to enter the limit (size of initial array)
        System.out.print("Enter the number of elements (limit) you want to insert initially (0 - " + maxSize + "): ");
        int n = scanner.nextInt();

        // Validate the limit
        if (n < 1 || n > maxSize) {
            System.out.println("Error: Invalid limit. The limit must be between 1 and " + maxSize + ".");
            System.out.println("Exiting program...");
            scanner.close();
            return;
        }

        // Read 'n' elements from the user
        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            array[i] = scanner.nextInt();
            currentSize++;
        }

        // Display the initial array
        System.out.print("Initial array: ");
        for (int i = 0; i < currentSize; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();

        // Loop to insert additional elements
        while (currentSize < maxSize) {
            System.out.print("Do you want to insert an element at the end? (yes/no): ");
            String userResponse = scanner.next();

            if (userResponse.equalsIgnoreCase("yes")) {
                System.out.print("Enter the element to insert: ");
                array[currentSize] = scanner.nextInt();
                currentSize++;

                // Display the updated array
                System.out.print("Updated array: ");
                for (int i = 0; i < currentSize; i++) {
                    System.out.print(array[i] + " ");
                }
                System.out.println();
            } else if (userResponse.equalsIgnoreCase("no")) {
                System.out.println("No more elements to insert. Exiting program.");
                break;
            } else {
                System.out.println("Invalid response. Please enter 'yes' or 'no'.");
            }
        }

        if (currentSize == maxSize) {
            System.out.println("The array is now full. No more elements can be inserted.");
        }

        // Close the scanner
        scanner.close();
    }
}
