import java.util.Scanner;

public class program1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Initialize array and variables
        int maxSize = 10; // Maximum size of the array
        int[] array = new int[maxSize];
        int currentSize = 0; // Tracks the current number of elements in the array

        // Ask user to enter the limit (size of array)
        System.out.print("Enter the number of elements (limit) you want to insert (0 - " + maxSize + "): ");
        int n = scanner.nextInt();

        // Validate the limit
        if (n < 0 || n > maxSize) {
            System.out.println("Error: Invalid limit. The limit must be between 0 and " + maxSize + ".");
            System.out.println("Exiting program...");
            scanner.close();
            return;
        }

        // Read 'n' elements from the user
        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            array[i] = scanner.nextInt();
            currentSize++;
        }

        // Display the initial array
        System.out.print("Initial array: ");
        for (int i = 0; i < currentSize; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();

        // Ask the user if they want to insert an element at the end
        System.out.print("Do you want to insert a new element at the end? (yes/no): ");
        String userResponse = scanner.next();

        if (userResponse.equalsIgnoreCase("yes")) {
            // Check if there is space to insert the element
            if (currentSize < maxSize) {
                System.out.print("Enter the element to insert: ");
                int element = scanner.nextInt();

                // Insert the element
                array[currentSize] = element;
                currentSize++;
                System.out.println("Element " + element + " inserted successfully!");

                // Display the updated array
                System.out.print("Updated array: ");
                for (int i = 0; i < currentSize; i++) {
                    System.out.print(array[i] + " ");
                }
                System.out.println();
            } else {
                System.out.println("Error: Array is full. Cannot insert more elements.");
            }
        } else {
            System.out.println("No new elements inserted. Exiting the program.");
        }

        // Close the scanner
        scanner.close();
    }
}

