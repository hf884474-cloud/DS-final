import java.util.Scanner;

class ArrayStack {
    private int top;
    private int[] stack;
    private int maxSize;

    // Constructor to initialize stack
    public ArrayStack(int size) {
        maxSize = size;
        stack = new int[maxSize];
        top = -1;
    }

    // Push an element onto the stack
    public void push(int num) {
        if (top == maxSize - 1) {
            System.out.println("Stack Overflow");
        } else {
            stack[++top] = num;
        }
    }

    // Pop an element from the stack
    public int pop() {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            return Integer.MIN_VALUE; // Return a special value indicating error
        } else {
            return stack[top--];
        }
    }

    // Check if the stack is empty
    public boolean isEmpty() {
        return top == -1;
    }
}

public class PostfixEvaluation {
    
    // Function to evaluate a postfix expression
    static int evaluatePostfix(String postfix) {
        ArrayStack stack = new ArrayStack(postfix.length());
        Scanner scanner = new Scanner(postfix); 

        while (scanner.hasNext()) {  
            if (scanner.hasNextInt()) { 
                stack.push(scanner.nextInt()); 
            } else {
                String op = scanner.next(); 
                if (stack.isEmpty()) {
                    System.out.println("Error: Invalid postfix expression.");
                    return Integer.MIN_VALUE;
                }
                int b = stack.pop();

                if (stack.isEmpty()) {
                    System.out.println("Error: Invalid postfix expression.");
                    return Integer.MIN_VALUE;
                }
                int a = stack.pop();

                switch (op.charAt(0)) { 
                    case '+': stack.push(a + b); break;
                    case '-': stack.push(a - b); break;
                    case '*': stack.push(a * b); break;
                    case '/': 
                        if (b == 0) {
                            System.out.println("Error: Division by zero.");
                            return Integer.MIN_VALUE;
                        }
                        stack.push(a / b);
                        break;
                    case '^': stack.push((int) Math.pow(a, b)); break;
                    default:
                        System.out.println("Error: Invalid operator " + op);
                        return Integer.MIN_VALUE;
                }
            }
        }
        scanner.close();  

        if (stack.isEmpty()) {
            System.out.println("Error: Invalid postfix expression.");
            return Integer.MIN_VALUE;
        }

        return stack.pop();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter postfix expression (numbers separated by spaces): ");
        String postfix = scanner.nextLine();  
        scanner.close();

        int result = evaluatePostfix(postfix);
        if (result != Integer.MIN_VALUE) {
            System.out.println("Result: " + result);
        }
    }
}
